%% ENGINEERING OPTIMIZATION: POLYMER, TEXTILE AND INDUSTRIAL APPLICATIONS
% Run this entire script in MATLAB. It creates solution and comparison plots.
% Requirements: Optimization Toolbox + Global Optimization Toolbox.
% Tested design uses standard solver-based syntax. Runtime values are measured
% on the computer running MATLAB; they are not pre-filled or fabricated.

clear; clc; close all;
rng(7,'twister');                 % reproducible stochastic solver starts

fprintf('\nPROBLEM 1: Recycled polymer filament formulation\n');
% Decision variables: x(1)=recycled PET mass fraction,
% x(2)=bio-based modifier fraction, x(3)=compatibilizer fraction.
% Fractions must add to one. Illustrative material property model.
x0 = [0.70; 0.20; 0.10];
lb1 = [0.50; 0.10; 0.05];
ub1 = [0.85; 0.35; 0.20];
Aeq1 = [1 1 1]; beq1 = 1;
opts1 = optimoptions('fmincon','Algorithm','sqp','Display','none');
[x1,f1] = fmincon(@polymerCost,x0,[],[],Aeq1,beq1,lb1,ub1, ...
                  @polymerConstraints,opts1);
fprintf('Fractions [rPET, bio-modifier, compatibilizer] = %.4f %.4f %.4f\n',x1);
fprintf('Estimated material cost index = %.4f\n',f1);

figure('Name','Problem 1 - polymer formulation');
bar(x1); grid on;
set(gca,'XTickLabel',{'Recycled PET','Bio-modifier','Compatibilizer'});
ylabel('Mass fraction'); title('Optimised recycled-polymer filament formulation');
saveas(gcf,'Problem1_Polymer_Formulation.png');

fprintf('\nPROBLEM 2: Lower-impact textile dyeing of recycled polyester\n');
% Decision variables z=[temperature (deg C), salt (g/L), dyeing time (min)].
% Solve with fmincon using explicit quality constraints.
z0 = [65;40;42];
lb2 = [50;20;25]; ub2 = [80;60;60];
opts2 = optimoptions('fmincon','Algorithm','sqp','Display','none', ...
                     'MaxIterations',500);
[z2,f2] = fmincon(@dyeCost,z0,[],[],[],[],lb2,ub2,@dyeConstraints,opts2);
[shade2,fix2] = dyeQuality(z2);
fprintf('T=%.2f C, salt=%.2f g/L, time=%.2f min\n',z2(1),z2(2),z2(3));
fprintf('Predicted shade=%.3f (target 50 +/- 1.5); fixation=%.3f (min 0.80)\n',shade2,fix2);
fprintf('Operating cost/impact index=%.4f\n',f2);

figure('Name','Problem 2 - dyeing variables');
subplot(1,3,1); bar(z2(1)); title('Temperature'); ylabel('deg C'); grid on;
subplot(1,3,2); bar(z2(2)); title('Salt concentration'); ylabel('g/L'); grid on;
subplot(1,3,3); bar(z2(3)); title('Dyeing time'); ylabel('min'); grid on;
sgtitle('Optimised dyeing conditions');
saveas(gcf,'Problem2_Dyeing_Conditions.png');

fprintf('\nPROBLEM 3: Production planning to reduce textile offcuts\n');
% Decision variables q=[shirts, trousers, workwear units] per shift.
% Minimise production cost + disposal cost. Demand, machine-hours and
% offcut/waste capacity are constraints. Units are pieces per shift.
q0 = [100;80;50];
lb3 = [80;60;40]; ub3 = [180;140;100];
A3 = [1.0 1.4 1.8; 0.08 0.12 0.18];
b3 = [430; 45];                    % machine-hours and waste kg ceilings
Aeq3 = []; beq3 = [];
opts3 = optimoptions('fmincon','Algorithm','sqp','Display','none');
[q3,f3] = fmincon(@productionCost,q0,A3,b3,Aeq3,beq3,lb3,ub3,[],opts3);
fprintf('Shift quantities [shirts, trousers, workwear] = %.2f %.2f %.2f\n',q3);
fprintf('Negative net contribution objective = %.2f (lower is better)\n',f3);
figure('Name','Problem 3 - production plan');
bar(q3); grid on;
set(gca,'XTickLabel',{'Shirts','Trousers','Workwear'});
ylabel('Pieces per shift'); title('Optimised production quantities');
saveas(gcf,'Problem3_Production_Plan.png');

%% SIX-SOLVER COMPARISON ON THE SAME DYEING PROBLEM
% All six solvers minimise the SAME penalised objective and use the SAME
% lower and upper bounds. Penalty terms represent shade and fixation limits.
% This makes the comparison possible because particleswarm and
% simulannealbnd accept bound constraints rather than general nonlinear ones.
fprintf('\nComparing six optimisers on the same dyeing problem...\n');
obj = @(z) dyePenaltyObjective(z);
x0 = z0; lb = lb2; ub = ub2;
names = {'fmincon','ga','particleswarm','patternsearch','surrogateopt','simulannealbnd'};
times = nan(6,1); fvals = nan(6,1); solutions = nan(6,3);
exitflags = nan(6,1);

% 1. fmincon
op = optimoptions('fmincon','Algorithm','sqp','Display','none','MaxIterations',300);
t=tic; [xx,ff,ef] = fmincon(obj,x0,[],[],[],[],lb,ub,[],op); times(1)=toc(t);
solutions(1,:)=xx; fvals(1)=ff; exitflags(1)=ef;

% 2. Genetic algorithm
op = optimoptions('ga','Display','none','PopulationSize',40,'MaxGenerations',60);
t=tic; [xx,ff,ef] = ga(obj,3,[],[],[],[],lb,ub,[],op); times(2)=toc(t);
solutions(2,:)=xx; fvals(2)=ff; exitflags(2)=ef;

% 3. Particle swarm
op = optimoptions('particleswarm','Display','none','SwarmSize',40,'MaxIterations',60);
t=tic; [xx,ff,ef] = particleswarm(obj,3,lb,ub,op); times(3)=toc(t);
solutions(3,:)=xx; fvals(3)=ff; exitflags(3)=ef;

% 4. Pattern search
op = optimoptions('patternsearch','Display','none','MaxIterations',150);
t=tic; [xx,ff,ef] = patternsearch(obj,x0,[],[],[],[],lb,ub,[],op); times(4)=toc(t);
solutions(4,:)=xx; fvals(4)=ff; exitflags(4)=ef;

% 5. Surrogate optimisation
op = optimoptions('surrogateopt','Display','none','MaxFunctionEvaluations',180);
t=tic; [xx,ff,ef] = surrogateopt(obj,lb,ub,op); times(5)=toc(t);
solutions(5,:)=xx; fvals(5)=ff; exitflags(5)=ef;

% 6. Simulated annealing
op = optimoptions('simulannealbnd','Display','none','MaxIterations',500);
t=tic; [xx,ff,ef] = simulannealbnd(obj,x0,lb,ub,op); times(6)=toc(t);
solutions(6,:)=xx; fvals(6)=ff; exitflags(6)=ef;

Comparison = table(names',times,fvals,solutions(:,1),solutions(:,2),solutions(:,3),exitflags, ...
 'VariableNames',{'Solver','Time_s','PenalisedObjective','Temperature_C','Salt_gL','Time_min','ExitFlag'});
disp(Comparison);
writetable(Comparison,'Solver_Comparison.csv');

figure('Name','Solver computation time');
bar(times); grid on;
set(gca,'XTick',1:6,'XTickLabel',names); xtickangle(25);
ylabel('Elapsed computation time (seconds)');
title('Runtime comparison: six MATLAB optimisation solvers');
saveas(gcf,'Solver_Runtime_Comparison.png');

figure('Name','Solver objective comparison');
bar(fvals); grid on;
set(gca,'XTick',1:6,'XTickLabel',names); xtickangle(25);
ylabel('Penalised objective value');
title('Solution quality comparison on the same dyeing problem');
saveas(gcf,'Solver_Objective_Comparison.png');

fprintf('\nFinished. PNG plots and Solver_Comparison.csv saved in the current folder.\n');

%% LOCAL FUNCTIONS
function cost = polymerCost(x)
% Illustrative cost index per kg of blended filament.
cost = 1.00*x(1) + 1.35*x(2) + 1.80*x(3);
end

function [c,ceq] = polymerConstraints(x)
% Tensile strength proxy must be >= 35 MPa; biodegradability score >= 0.25.
tensile = 48*x(1) + 25*x(2) + 38*x(3) - 8*x(1)*x(2);
bioScore = 0.05*x(1) + 0.85*x(2) + 0.20*x(3);
c = [35-tensile; 0.25-bioScore]; % fmincon requires c <= 0
ceq = [];
end

function cost = dyeCost(z)
T=z(1); S=z(2); t=z(3);
% Proxy combines heating energy, salt use and machine occupation time.
cost = 0.045*(T-45) + 0.018*S + 0.012*t;
end

function [shade,fixation] = dyeQuality(z)
T=z(1); S=z(2); t=z(3);
shade = 50 + 0.18*(T-65) + 0.08*(S-40) + 0.03*(t-42) ...
        + 0.001*(T-65)*(t-42);
fixation = 0.72 + 0.004*(T-50) + 0.002*(t-25) ...
           - 0.00003*(S-40)^2;
end

function [c,ceq] = dyeConstraints(z)
[shade,fixation] = dyeQuality(z);
c = [abs(shade-50)-1.5; 0.80-fixation];
ceq = [];
end

function value = dyePenaltyObjective(z)
% Smooth penalty approximation for the common six-solver comparison.
% Absolute shade deviation is represented with a squared positive-part
% penalty; all solvers therefore minimise one scalar objective.
[shade,fixation] = dyeQuality(z);
shadeViolation = max(0,abs(shade-50)-1.5);
fixViolation = max(0,0.80-fixation);
value = dyeCost(z) + 1e4*shadeViolation^2 + 1e4*fixViolation^2;
end

function cost = productionCost(q)
% fmincon minimises, so use the negative of net contribution to maximise it.
% Contribution per unit is illustrative; offcut disposal is deducted.
unitContribution = [4.0; 6.0; 8.0];
offcutKg = [0.08;0.12;0.18];
netContribution = unitContribution'*q - 0.35*(offcutKg'*q);
cost = -netContribution;
end
